from http.server import BaseHTTPRequestHandler, HTTPServer
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(302)
        self.send_header("Location", "http://cdn/_private/backup/.env")
        self.end_headers()
HTTPServer(("0.0.0.0", 8081), Handler).serve_forever()