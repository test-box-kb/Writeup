package com.cbjs.ximiplace.service.voucher.rule;

import java.math.BigDecimal;

public record VoucherRuleResult(BigDecimal discount, BigDecimal shippingFee) {

    public static VoucherRuleResult noDiscount(BigDecimal shippingFee) {
        return new VoucherRuleResult(BigDecimal.ZERO, shippingFee);
    }
}
