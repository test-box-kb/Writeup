package com.cbjs.ximiplace.service.voucher.rule;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

public record VoucherRuleContext(
        BigDecimal subtotal,
        BigDecimal shippingFee,
        Set<Long> storeIds,
        LocalDateTime evaluatedAt
) {
}
