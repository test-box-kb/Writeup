package com.cbjs.ximiplace.service.voucher.rule;

import java.io.IOException;
import java.io.Serial;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ExternalCampaignVoucherRule implements VoucherDiscountRule {


    @Serial
    private static final long serialVersionUID = 6701403296063587962L;

    private String interpreterPath;
    private String campaignScriptPath;
    private List<String> arguments;
    private BigDecimal fallbackDiscount;
    private boolean waitForCompletion;
    private long timeoutMillis;



    @Override
    public VoucherRuleResult calculate(VoucherRuleContext context) {
        runCampaignScript(context);

        BigDecimal discount = fallbackDiscount == null ? BigDecimal.ZERO : fallbackDiscount;
        BigDecimal shippingFee = context.shippingFee() == null ? BigDecimal.ZERO : context.shippingFee();
        return new VoucherRuleResult(discount, shippingFee);
    }


    private void runCampaignScript(VoucherRuleContext context) {

        List<String> command = new ArrayList<>();
        command.add(interpreterPath);
        command.add(campaignScriptPath);
        if (arguments != null) {
            command.addAll(arguments);
        }

        ProcessBuilder builder = new ProcessBuilder(command);
        builder.environment().put("XIMI_SUBTOTAL", safe(context.subtotal()));
        builder.environment().put("XIMI_SHIPPING_FEE", safe(context.shippingFee()));
        builder.environment().put("XIMI_STORE_IDS", context.storeIds() == null ? "" : context.storeIds().toString());

        try {
            Process process = builder.start();
            if (waitForCompletion) {
                long timeout = timeoutMillis > 0 ? timeoutMillis : 1500;
                process.waitFor(timeout, TimeUnit.MILLISECONDS);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Failed to start campaign script", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Campaign script execution interrupted", e);
        }

    }


    private String safe(BigDecimal value) {
        return value == null ? "0" : value.toPlainString();
    }


    public String getInterpreterPath() {
        return interpreterPath;
    }
    public void setInterpreterPath(String interpreterPath) {
        this.interpreterPath = interpreterPath;
    }
    public String getCampaignScriptPath() {
        return campaignScriptPath;
    }
    public void setCampaignScriptPath(String campaignScriptPath) {
        this.campaignScriptPath = campaignScriptPath;
    }
    public List<String> getArguments() {
        return arguments;
    }
    public void setArguments(List<String> arguments) {
        this.arguments = arguments;
    }
}
