package com.cbjs.ximiplace.service.voucher.rule;

import java.io.Serializable;

public interface VoucherDiscountRule extends Serializable {

    VoucherRuleResult calculate(VoucherRuleContext context);
}
